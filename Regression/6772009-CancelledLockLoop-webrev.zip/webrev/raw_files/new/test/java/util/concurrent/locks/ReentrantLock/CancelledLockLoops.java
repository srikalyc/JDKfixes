/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */

/*
 * This file is available under and governed by the GNU General Public
 * License version 2 only, as published by the Free Software Foundation.
 * However, the following notice accompanied the original version of this
 * file:
 *
 * Written by Doug Lea with assistance from members of JCP JSR-166
 * Expert Group and released to the public domain, as explained at
 * http://creativecommons.org/publicdomain/zero/1.0/
 */

/*
 * @test
 * @bug 4486658
 * @compile -source 1.5 CancelledLockLoops.java
 * @run main/timeout=2800 CancelledLockLoops
 * @summary tests lockInterruptibly.
 * Checks for responsiveness of locks to interrupts. Runs under that
 * assumption that ITERS_VALUE computations require more than TIMEOUT
 * msecs to complete.
 */

import java.util.concurrent.*;
import java.util.concurrent.locks.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

public final class CancelledLockLoops {
    static final Random rng = new Random();
    static boolean print = false;
    static final int ITERS = 5000000;
    static final long TIMEOUT = 100;

    public static void main(String[] args) throws Exception {
        int maxThreads = (args.length > 0) ? Integer.parseInt(args[0]) : 5;

        print = true;

        for (int i = 2; i <= maxThreads; i += (i+1) >>> 1) {
            System.out.print("# of Threads " + i + ", ");
            try {
                new ReentrantLockLoop(i).test();
            }
            catch (BrokenBarrierException bb) {
                // OK, ignore
            }
            Thread.sleep(TIMEOUT);
        }
    }

    static final class ReentrantLockLoop implements Runnable {
        private int v = rng.nextInt();
        private int completed;
        private final AtomicInteger result = new AtomicInteger(17);
        private final ReentrantLock lock = new ReentrantLock();
        private final LoopHelpers.BarrierTimer timer = new LoopHelpers.BarrierTimer();
        private final CyclicBarrier barrier;
        private final int nthreads;
        ReentrantLockLoop(int nthreads) {
            this.nthreads = nthreads;
            barrier = new CyclicBarrier(nthreads+1, timer);
        }

        final void test() throws Exception {
            Thread[] threads = new Thread[nthreads];
            for (int i = 0; i < threads.length; ++i) 
                threads[i] = new Thread(this, "T" + i);
            for (int i = 0; i < threads.length; ++i) {
                threads[i].start();
                System.out.print(" " + threads[i].getName());
            }
            System.out.println("");
            Thread[] cancels = threads.clone();
            Collections.shuffle(Arrays.asList(cancels), rng);
            barrier.await();
            Thread.sleep(TIMEOUT);
            for (int i = 0; i < cancels.length-2; ++i) {
                cancels[i].interrupt();
                // make sure all OK even when cancellations spaced out
                if ( (i & 3) == 0)
                    Thread.sleep(1 + rng.nextInt(10));
            }
            try {
                barrier.await();
            }
            catch (BrokenBarrierException bb) {
                /*
                 * Why catch this here? because we still want to print the value
                 * of c and result before leaving.
                 */
            }
            if (print) {
                long time = timer.getTime();
                double secs = (double)(time) / 1000000000.0;
                System.out.println(secs + "s run time");
            }

            int c;
            lock.lock();
            try {
                c = completed;
            }
            finally {
                lock.unlock();
            }
            int r = result.get();
            if (r == 0) // avoid overoptimization
                System.out.println("useless result: " + r);
            else
                System.out.println("result: " + r);
            System.out.println("completed=" + c + "\n");
            if (c != 2)
                throw new Error("Completed != 2");
        }

        public final void run() {
            int sum = 0;
            try {
                barrier.await();
                sum = v;
                int x = 0;
                int n = ITERS;
                do {
                    try {
                        lock.lockInterruptibly();
                    }
                    catch (InterruptedException ie) {
                        break;
                    }
                    try {
                        v = x = LoopHelpers.compute1(v);
                    }
                    finally {
                        lock.unlock();
                    }
                    sum += LoopHelpers.compute2(x);
                } while (n-- > 0);
                if (n <= 0) {
                    lock.lock();
                    try {
                        ++completed;
                        // To understand which thread is updating the completed.
                        System.out.println("Thread " + Thread.currentThread().getName()
                                + " updated 'completed' to " + completed);
                    }
                    finally {
                        lock.unlock();
                    }
                }
                /*
                 * If a BrokenBarrierException happens here(due to interrupt)we 
                 * must still update the result so moved it to finally. 
                 */
                barrier.await();
            }
            catch (Exception ex) {
                ex.printStackTrace();
                return;
            } finally {
                result.addAndGet(sum);
            }
        }
    }

}
